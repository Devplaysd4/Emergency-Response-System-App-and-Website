# Emergency Response System App

This is a Kivy-based mobile application designed to be an emergency response system for tourists. It includes features like user registration, a home screen with alerts, a trip itinerary, an SOS button, and a map view.

## Setup and Installation

To run this application, you will need to have Python and Kivy installed. You will also need to install the dependencies listed in the `requirements.txt` file.

1.  **Clone the repository:**
    ```
    git clone <repository-url>
    ```

2.  **Install the dependencies:**
    ```
    pip install -r requirements.txt
    ```

3.  **Install the mapview widget:**
    ```
    kivy garden install mapview
    ```

4.  **Run the application:**
    ```
    python amain.py
    ```